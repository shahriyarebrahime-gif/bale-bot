export const languages = ['en', 'fa', 'de'] as const;
export type Lang = (typeof languages)[number];

export function isLang(value: string): value is Lang {
  return (languages as readonly string[]).includes(value);
}

export const langInfo: Record<
  Lang,
  { label: string; dir: 'ltr' | 'rtl'; locale: string; ogLocale: string }
> = {
  en: { label: 'EN', dir: 'ltr', locale: 'en-US', ogLocale: 'en_US' },
  fa: { label: 'FA', dir: 'rtl', locale: 'fa-IR', ogLocale: 'fa_IR' },
  de: { label: 'DE', dir: 'ltr', locale: 'de-DE', ogLocale: 'de_DE' },
};
