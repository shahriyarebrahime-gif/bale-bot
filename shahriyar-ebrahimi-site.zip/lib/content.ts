import type { Lang } from './i18n';

export interface Dict {
  name: string;
  meta: { title: string; description: string };
  ui: {
    skip: string;
    menu: string;
    close: string;
    language: string;
    viewCertificate: string;
    backToResearch: string;
    showPhone: string;
  };
  nav: { home: string; about: string; research: string; achievements: string; contact: string; cv: string };
  hero: { role: string; line: string; tag: string; ctaResearch: string; ctaAchievements: string };
  highlights: { label: string; value: number; decimals?: number; suffix?: string }[];
  about: { title: string; paragraphs: string[]; schoolTitle: string; schoolText: string };
  profile: {
    title: string;
    rows: { label: string; value: string }[];
    performance: { label: string; value: string };
  };
  research: {
    title: string;
    paperTitle: string;
    paperTitleLang: Lang;
    altTitle: string;
    altTitleLang: Lang;
    topicLabel: string;
    topic: string;
    facts: { label: string; value: string }[];
    read: string;
    publicationPage: string;
    // Optional: add { heading, text } entries (abstract, method, findings...) and they appear on the research page.
    sections?: { heading: string; text: string }[];
  };
  achievements: {
    title: string;
    items: { id: string; name: string }[];
    status: string;
    year: string;
    note: string;
  };
  interests: { title: string; items: string[] };
  languages: { title: string; items: { name: string; level: string }[] };
  journey: { title: string; items: { title: string; text?: string; future?: boolean }[] };
  contact: { title: string; text: string; email: string };
  footer: string;
}

const en: Dict = {
  name: 'Shahriyar Ebrahimi',
  meta: {
    title: 'Shahriyar Ebrahimi | Mathematics & Physics Student',
    description:
      'Shahriyar Ebrahimi is a Grade 11 Mathematics & Physics student at Ejei 3 Gifted School in Isfahan, Iran, with a Grade 10 average of 19.45/20, a research publication on energy harvesting, and five first-stage olympiad qualifications.',
  },
  ui: {
    skip: 'Skip to content',
    menu: 'Menu',
    close: 'Close',
    language: 'Language',
    viewCertificate: 'View certificate',
    backToResearch: 'Back to research',
    showPhone: 'Show phone number',
  },
  nav: { home: 'Home', about: 'About', research: 'Research', achievements: 'Achievements', contact: 'Contact', cv: 'Download CV' },
  hero: {
    role: 'Mathematics & Physics Student',
    line: 'Grade 11 · Ejei 3 Gifted School · Isfahan, Iran',
    tag: 'Academic Profile · Research · Achievements',
    ctaResearch: 'Read research',
    ctaAchievements: 'Achievements',
  },
  highlights: [
    { label: 'Grade 10 academic average', value: 19.45, decimals: 2, suffix: ' / 20' },
    { label: 'Scientific research publication', value: 1 },
    { label: 'First-stage academic qualifications', value: 5 },
    { label: 'Current grade', value: 11 },
  ],
  about: {
    title: 'About me',
    paragraphs: [
      'I am Shahriyar Ebrahimi, a Grade 11 Mathematics and Physics student at Ejei 3 Gifted School in Isfahan, Iran.',
      'My academic interests include mathematics, physics, engineering, scientific research, and continuous learning. Alongside my school education, I have been developing my academic profile through scientific research, academic competitions, independent learning, and other educational activities.',
      'This website presents my academic background, research, achievements, interests, and the work I have undertaken throughout my educational journey.',
    ],
    schoolTitle: 'Ejei 3 Gifted School',
    schoolText: 'I am a student at Ejei 3 Gifted School in Isfahan, Iran.',
  },
  profile: {
    title: 'Academic profile',
    rows: [
      { label: 'Full name', value: 'Shahriyar Ebrahimi' },
      { label: 'Field of study', value: 'Mathematics & Physics' },
      { label: 'Current grade', value: '11th grade' },
      { label: 'School', value: 'Ejei 3 Gifted School' },
      { label: 'Location', value: 'Isfahan, Iran' },
      { label: 'Academic average', value: '19.45 / 20 (Grade 10)' },
      { label: 'Languages', value: 'Persian (native) · English (B2) · German (A1)' },
    ],
    performance: { label: 'Grade 10 average', value: '19.45 / 20' },
  },
  research: {
    title: 'Research & publication',
    paperTitle: 'Analysis of Waste Energy Recovery in High-Traffic Buildings Using Energy Harvesting Technologies',
    paperTitleLang: 'en',
    altTitle: 'بررسی و تحلیل امکان بازیابی انرژی‌های اتلافی در ساختمان‌های پرتردد با استفاده از فناوری‌های برداشت انرژی',
    altTitleLang: 'fa',
    topicLabel: 'Research topic',
    topic:
      'This research examines the potential of recovering energy that is otherwise lost in high-traffic buildings, using energy harvesting technologies.',
    facts: [
      { label: 'Author', value: 'Shahriyar Ebrahimi' },
      { label: 'Field', value: 'Energy harvesting · Sustainable energy · Engineering' },
      { label: 'Type', value: 'Scientific research' },
      { label: 'Year', value: '2026' },
      { label: 'Publication source', value: 'BrainyScholar' },
    ],
    read: 'Read research',
    publicationPage: 'Publication page',
  },
  achievements: {
    title: 'Olympiads & academic achievements',
    items: [
      { id: 'math', name: 'Mathematics Olympiad' },
      { id: 'physics', name: 'Physics Olympiad' },
      { id: 'chemistry', name: 'Chemistry Olympiad' },
      { id: 'persian-literature', name: 'Persian Literature Olympiad' },
      { id: 'media-literacy', name: 'Media Literacy Olympiad' },
    ],
    status: 'First stage qualified',
    year: '2026',
    note: 'These entries record qualification for the first stage only.',
  },
  interests: {
    title: 'Academic interests',
    items: ['Mathematics', 'Physics', 'Engineering', 'Scientific research', 'Energy & technology'],
  },
  languages: {
    title: 'Languages',
    items: [
      { name: 'Persian', level: 'Native' },
      { name: 'English', level: 'B2 · Upper-intermediate' },
      { name: 'German', level: 'A1 · Beginner' },
    ],
  },
  journey: {
    title: 'Academic journey',
    items: [
      { title: 'Grade 10 · Mathematics & Physics', text: 'Academic average: 19.45 / 20' },
      { title: 'Grade 11 · Mathematics & Physics', text: 'Ejei 3 Gifted School' },
      { title: 'Scientific research', text: 'Energy harvesting in high-traffic buildings' },
      { title: 'Academic competitions', text: 'Multiple first-stage qualifications' },
      { title: 'Future academic development', future: true },
    ],
  },
  contact: {
    title: 'Contact',
    text: 'For academic or professional inquiries, feel free to get in touch.',
    email: 'Email me →',
  },
  footer: 'Academic profile',
};

const fa: Dict = {
  name: 'شهریار ابراهیمی',
  meta: {
    title: 'شهریار ابراهیمی | دانش‌آموز ریاضی‌فیزیک',
    description:
      'شهریار ابراهیمی، دانش‌آموز پایه یازدهم ریاضی‌فیزیک در دبیرستان تیزهوشان اژه‌ای ۳ اصفهان؛ دارای معدل ۱۹٫۴۵ در پایه دهم، یک مقاله پژوهشی در حوزه برداشت انرژی و قبولی در مرحله اول پنج المپیاد.',
  },
  ui: {
    skip: 'رفتن به محتوا',
    menu: 'منو',
    close: 'بستن',
    language: 'زبان',
    viewCertificate: 'مشاهده مدرک',
    backToResearch: 'بازگشت به پژوهش',
    showPhone: 'نمایش شماره تماس',
  },
  nav: { home: 'خانه', about: 'درباره من', research: 'پژوهش', achievements: 'دستاوردها', contact: 'تماس', cv: 'دانلود رزومه' },
  hero: {
    role: 'دانش‌آموز ریاضی‌فیزیک',
    line: 'پایه یازدهم · تیزهوشان اژه‌ای ۳ · اصفهان، ایران',
    tag: 'پروفایل تحصیلی · پژوهش · دستاوردها',
    ctaResearch: 'مطالعه پژوهش',
    ctaAchievements: 'دستاوردها',
  },
  highlights: [
    { label: 'معدل پایه دهم', value: 19.45, decimals: 2, suffix: ' از ۲۰' },
    { label: 'مقاله پژوهشی علمی', value: 1 },
    { label: 'قبولی در مرحله اول', value: 5 },
    { label: 'پایه تحصیلی فعلی', value: 11 },
  ],
  about: {
    title: 'درباره من',
    paragraphs: [
      'من شهریار ابراهیمی هستم، دانش‌آموز پایه یازدهم رشته ریاضی‌فیزیک در دبیرستان تیزهوشان اژه‌ای ۳ اصفهان.',
      'علایق علمی من شامل ریاضیات، فیزیک، مهندسی، پژوهش علمی و یادگیری مستمر است. در کنار تحصیل در مدرسه، پروفایل تحصیلی‌ام را از طریق پژوهش علمی، مسابقات علمی، یادگیری مستقل و دیگر فعالیت‌های آموزشی توسعه داده‌ام.',
      'این وب‌سایت پیشینه تحصیلی، پژوهش، دستاوردها، علایق و فعالیت‌های من را در مسیر تحصیلی‌ام معرفی می‌کند.',
    ],
    schoolTitle: 'دبیرستان تیزهوشان اژه‌ای ۳',
    schoolText: 'دانش‌آموز دبیرستان تیزهوشان اژه‌ای ۳ در اصفهان هستم.',
  },
  profile: {
    title: 'پروفایل تحصیلی',
    rows: [
      { label: 'نام کامل', value: 'شهریار ابراهیمی' },
      { label: 'رشته تحصیلی', value: 'ریاضی‌فیزیک' },
      { label: 'پایه فعلی', value: 'یازدهم' },
      { label: 'مدرسه', value: 'دبیرستان تیزهوشان اژه‌ای ۳' },
      { label: 'محل', value: 'اصفهان، ایران' },
      { label: 'معدل', value: '۱۹٫۴۵ از ۲۰ (پایه دهم)' },
      { label: 'زبان‌ها', value: 'فارسی (زبان مادری) · انگلیسی (B2) · آلمانی (A1)' },
    ],
    performance: { label: 'معدل پایه دهم', value: '۱۹٫۴۵ از ۲۰' },
  },
  research: {
    title: 'پژوهش و انتشار',
    paperTitle: 'بررسی و تحلیل امکان بازیابی انرژی‌های اتلافی در ساختمان‌های پرتردد با استفاده از فناوری‌های برداشت انرژی',
    paperTitleLang: 'fa',
    altTitle: 'Analysis of Waste Energy Recovery in High-Traffic Buildings Using Energy Harvesting Technologies',
    altTitleLang: 'en',
    topicLabel: 'موضوع پژوهش',
    topic: 'این پژوهش امکان بازیابی انرژی‌های اتلافی در ساختمان‌های پرتردد را با استفاده از فناوری‌های برداشت انرژی بررسی می‌کند.',
    facts: [
      { label: 'نویسنده', value: 'شهریار ابراهیمی' },
      { label: 'حوزه', value: 'برداشت انرژی · انرژی پایدار · مهندسی' },
      { label: 'نوع', value: 'پژوهش علمی' },
      { label: 'سال', value: '۲۰۲۶' },
      { label: 'منبع انتشار', value: 'BrainyScholar' },
    ],
    read: 'مطالعه پژوهش',
    publicationPage: 'صفحه انتشار',
  },
  achievements: {
    title: 'المپیادها و دستاوردهای علمی',
    items: [
      { id: 'math', name: 'المپیاد ریاضی' },
      { id: 'physics', name: 'المپیاد فیزیک' },
      { id: 'chemistry', name: 'المپیاد شیمی' },
      { id: 'persian-literature', name: 'المپیاد ادبیات فارسی' },
      { id: 'media-literacy', name: 'المپیاد سواد رسانه‌ای' },
    ],
    status: 'قبولی در مرحله اول',
    year: '۲۰۲۶',
    note: 'این موارد فقط قبولی در مرحله اول را ثبت می‌کنند.',
  },
  interests: {
    title: 'علایق علمی',
    items: ['ریاضیات', 'فیزیک', 'مهندسی', 'پژوهش علمی', 'انرژی و فناوری'],
  },
  languages: {
    title: 'زبان‌ها',
    items: [
      { name: 'فارسی', level: 'زبان مادری' },
      { name: 'انگلیسی', level: 'B2 · متوسط رو به بالا' },
      { name: 'آلمانی', level: 'A1 · مبتدی' },
    ],
  },
  journey: {
    title: 'مسیر تحصیلی',
    items: [
      { title: 'پایه دهم · ریاضی‌فیزیک', text: 'معدل: ۱۹٫۴۵ از ۲۰' },
      { title: 'پایه یازدهم · ریاضی‌فیزیک', text: 'تیزهوشان اژه‌ای ۳' },
      { title: 'پژوهش علمی', text: 'برداشت انرژی در ساختمان‌های پرتردد' },
      { title: 'مسابقات علمی', text: 'قبولی در مرحله اول چند المپیاد و مسابقه' },
      { title: 'توسعه تحصیلی در آینده', future: true },
    ],
  },
  contact: {
    title: 'تماس',
    text: 'برای موارد تحصیلی یا حرفه‌ای می‌توانید با من در ارتباط باشید.',
    email: 'ارسال ایمیل ←',
  },
  footer: 'پروفایل تحصیلی',
};

const de: Dict = {
  name: 'Shahriyar Ebrahimi',
  meta: {
    title: 'Shahriyar Ebrahimi | Schüler für Mathematik & Physik',
    description:
      'Shahriyar Ebrahimi ist Schüler der 11. Klasse (Mathematik & Physik) an der Ejei 3 Gifted School in Isfahan, Iran, mit einem Notendurchschnitt von 19,45/20 in der 10. Klasse, einer Forschungspublikation zu Energy Harvesting und fünf Qualifikationen für die erste Runde von Olympiaden.',
  },
  ui: {
    skip: 'Zum Inhalt springen',
    menu: 'Menü',
    close: 'Schließen',
    language: 'Sprache',
    viewCertificate: 'Zertifikat ansehen',
    backToResearch: 'Zurück zur Forschung',
    showPhone: 'Telefonnummer anzeigen',
  },
  nav: { home: 'Start', about: 'Über mich', research: 'Forschung', achievements: 'Erfolge', contact: 'Kontakt', cv: 'Lebenslauf (PDF)' },
  hero: {
    role: 'Schüler für Mathematik & Physik',
    line: '11. Klasse · Ejei 3 Gifted School · Isfahan, Iran',
    tag: 'Akademisches Profil · Forschung · Erfolge',
    ctaResearch: 'Forschung lesen',
    ctaAchievements: 'Erfolge',
  },
  highlights: [
    { label: 'Notendurchschnitt der 10. Klasse', value: 19.45, decimals: 2, suffix: ' / 20' },
    { label: 'Wissenschaftliche Forschungspublikation', value: 1 },
    { label: 'Qualifikationen für die erste Runde', value: 5 },
    { label: 'Aktuelle Klassenstufe', value: 11 },
  ],
  about: {
    title: 'Über mich',
    paragraphs: [
      'Ich bin Shahriyar Ebrahimi, Schüler der 11. Klasse mit Schwerpunkt Mathematik und Physik an der Ejei 3 Gifted School in Isfahan, Iran.',
      'Zu meinen akademischen Interessen gehören Mathematik, Physik, Ingenieurwesen, wissenschaftliche Forschung und kontinuierliches Lernen. Neben meiner schulischen Ausbildung entwickle ich mein akademisches Profil durch wissenschaftliche Forschung, Wettbewerbe, selbstständiges Lernen und weitere Bildungsaktivitäten.',
      'Diese Website stellt meinen akademischen Hintergrund, meine Forschung, meine Erfolge, meine Interessen und meine bisherige Arbeit auf meinem Bildungsweg vor.',
    ],
    schoolTitle: 'Ejei 3 Gifted School',
    schoolText: 'Ich besuche die Ejei 3 Gifted School in Isfahan, Iran.',
  },
  profile: {
    title: 'Akademisches Profil',
    rows: [
      { label: 'Vollständiger Name', value: 'Shahriyar Ebrahimi' },
      { label: 'Fachrichtung', value: 'Mathematik & Physik' },
      { label: 'Aktuelle Klasse', value: '11. Klasse' },
      { label: 'Schule', value: 'Ejei 3 Gifted School' },
      { label: 'Ort', value: 'Isfahan, Iran' },
      { label: 'Notendurchschnitt', value: '19,45 / 20 (10. Klasse)' },
      { label: 'Sprachen', value: 'Persisch (Muttersprache) · Englisch (B2) · Deutsch (A1)' },
    ],
    performance: { label: 'Durchschnitt der 10. Klasse', value: '19,45 / 20' },
  },
  research: {
    title: 'Forschung & Publikation',
    paperTitle: 'Analysis of Waste Energy Recovery in High-Traffic Buildings Using Energy Harvesting Technologies',
    paperTitleLang: 'en',
    altTitle: 'بررسی و تحلیل امکان بازیابی انرژی‌های اتلافی در ساختمان‌های پرتردد با استفاده از فناوری‌های برداشت انرژی',
    altTitleLang: 'fa',
    topicLabel: 'Forschungsthema',
    topic:
      'Diese Arbeit untersucht, inwieweit sich Energie, die in stark frequentierten Gebäuden ungenutzt verloren geht, mithilfe von Energy-Harvesting-Technologien zurückgewinnen lässt.',
    facts: [
      { label: 'Autor', value: 'Shahriyar Ebrahimi' },
      { label: 'Fachgebiet', value: 'Energy Harvesting · Nachhaltige Energie · Ingenieurwesen' },
      { label: 'Art', value: 'Wissenschaftliche Forschung' },
      { label: 'Jahr', value: '2026' },
      { label: 'Publikationsquelle', value: 'BrainyScholar' },
    ],
    read: 'Forschung lesen',
    publicationPage: 'Publikationsseite',
  },
  achievements: {
    title: 'Olympiaden & akademische Erfolge',
    items: [
      { id: 'math', name: 'Mathematik-Olympiade' },
      { id: 'physics', name: 'Physik-Olympiade' },
      { id: 'chemistry', name: 'Chemie-Olympiade' },
      { id: 'persian-literature', name: 'Olympiade für persische Literatur' },
      { id: 'media-literacy', name: 'Olympiade für Medienkompetenz' },
    ],
    status: 'Für die erste Runde qualifiziert',
    year: '2026',
    note: 'Diese Einträge dokumentieren ausschließlich die Qualifikation für die erste Runde.',
  },
  interests: {
    title: 'Akademische Interessen',
    items: ['Mathematik', 'Physik', 'Ingenieurwesen', 'Wissenschaftliche Forschung', 'Energie & Technologie'],
  },
  languages: {
    title: 'Sprachen',
    items: [
      { name: 'Persisch', level: 'Muttersprache' },
      { name: 'Englisch', level: 'B2 · Gehobene Mittelstufe' },
      { name: 'Deutsch', level: 'A1 · Anfänger' },
    ],
  },
  journey: {
    title: 'Akademischer Werdegang',
    items: [
      { title: '10. Klasse · Mathematik & Physik', text: 'Notendurchschnitt: 19,45 / 20' },
      { title: '11. Klasse · Mathematik & Physik', text: 'Ejei 3 Gifted School' },
      { title: 'Wissenschaftliche Forschung', text: 'Energy Harvesting in stark frequentierten Gebäuden' },
      { title: 'Akademische Wettbewerbe', text: 'Mehrere Qualifikationen für die erste Runde' },
      { title: 'Künftige akademische Entwicklung', future: true },
    ],
  },
  contact: {
    title: 'Kontakt',
    text: 'Für akademische oder berufliche Anfragen können Sie sich gern bei mir melden.',
    email: 'E-Mail schreiben →',
  },
  footer: 'Akademisches Profil',
};

export const dict: Record<Lang, Dict> = { en, fa, de };
