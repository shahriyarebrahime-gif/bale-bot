// Central place for facts that are not translated.
// Edit here when something changes.

export const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL ?? 'https://example.com').replace(/\/$/, '');
export const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? '';

export const email = 'shahriyarebrahime@gmail.com';

export const paperUrl = 'https://brainyscholar.com/?p=150594';
export const paperSlug = 'energy-harvesting-buildings';

// Set to true after you put your CV at public/cv.pdf
export const hasCv = false;

// Add certificate links by achievement id, for example:
// export const certificates = { math: `${basePath}/certificates/math.pdf` };
export const certificates: Record<string, string | undefined> = {};
