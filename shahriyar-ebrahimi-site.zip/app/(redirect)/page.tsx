const script = `(function(){var l='en';try{var s=localStorage.getItem('lang');var n=(navigator.language||'en').slice(0,2).toLowerCase();l=s||n;}catch(e){}if(l!=='fa'&&l!=='de')l='en';location.replace('./'+l+'/');})();`;

export default function Root() {
  return (
    <>
      <script dangerouslySetInnerHTML={{ __html: script }} />
      <noscript>
        <meta httpEquiv="refresh" content="0;url=./en/" />
      </noscript>
      <h1>Shahriyar Ebrahimi</h1>
      <p>
        <a style={{ color: '#9DB6E0' }} href="./en/">English</a> ·{' '}
        <a style={{ color: '#9DB6E0' }} href="./fa/">فارسی</a> ·{' '}
        <a style={{ color: '#9DB6E0' }} href="./de/">Deutsch</a>
      </p>
    </>
  );
}
