import type { Metadata } from 'next';
import type { ReactNode } from 'react';

export const metadata: Metadata = {
  title: 'Shahriyar Ebrahimi',
  description: 'Academic profile of Shahriyar Ebrahimi, Mathematics & Physics student.',
};

export default function RedirectLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: 'system-ui, sans-serif', padding: '3rem 1.5rem', background: '#0E1B33', color: '#fff' }}>
        {children}
      </body>
    </html>
  );
}
