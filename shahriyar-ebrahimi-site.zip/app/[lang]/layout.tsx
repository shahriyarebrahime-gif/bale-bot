import type { Metadata, Viewport } from 'next';
import { Bricolage_Grotesque, Public_Sans, Vazirmatn } from 'next/font/google';
import { notFound } from 'next/navigation';
import type { ReactNode } from 'react';
import Header from '@/components/Header';
import { dict } from '@/lib/content';
import { isLang, langInfo, languages } from '@/lib/i18n';
import { hasCv, siteUrl } from '@/lib/site';
import '../globals.css';

const head = Bricolage_Grotesque({ subsets: ['latin'], variable: '--font-head', display: 'swap' });
const body = Public_Sans({ subsets: ['latin'], variable: '--font-body', display: 'swap' });
const fa = Vazirmatn({ subsets: ['arabic', 'latin'], variable: '--font-fa', display: 'swap' });

export const dynamicParams = false;

export function generateStaticParams() {
  return languages.map((lang) => ({ lang }));
}

export const viewport: Viewport = { themeColor: '#0E1B33' };

export async function generateMetadata({ params }: { params: Promise<{ lang: string }> }): Promise<Metadata> {
  const { lang } = await params;
  if (!isLang(lang)) return {};
  const d = dict[lang];
  const alt = Object.fromEntries(languages.map((l) => [l, `${siteUrl}/${l}/`]));
  return {
    title: d.meta.title,
    description: d.meta.description,
    authors: [{ name: 'Shahriyar Ebrahimi' }],
    alternates: { canonical: `${siteUrl}/${lang}/`, languages: { ...alt, 'x-default': `${siteUrl}/en/` } },
    openGraph: {
      type: 'website',
      title: d.meta.title,
      description: d.meta.description,
      url: `${siteUrl}/${lang}/`,
      siteName: 'Shahriyar Ebrahimi',
      locale: langInfo[lang].ogLocale,
    },
    twitter: { card: 'summary', title: d.meta.title, description: d.meta.description },
    robots: { index: true, follow: true },
  };
}

export default async function LangLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ lang: string }>;
}) {
  const { lang } = await params;
  if (!isLang(lang)) notFound();
  const d = dict[lang];

  return (
    <html
      lang={lang}
      dir={langInfo[lang].dir}
      className={`${head.variable} ${body.variable} ${fa.variable}`}
      suppressHydrationWarning
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: "document.documentElement.classList.add('js')" }} />
        <noscript>
          <style>{'.reveal{opacity:1!important;transform:none!important}'}</style>
        </noscript>
      </head>
      <body>
        <a className="skip" href="#main">
          {d.ui.skip}
        </a>
        <Header lang={lang} name={d.name} nav={d.nav} ui={d.ui} hasCv={hasCv} />
        {children}
        <footer>
          <div className="wrap foot">
            <span>© {new Date().getFullYear()} {d.name}</span>
            <span>{d.footer}</span>
          </div>
        </footer>
      </body>
    </html>
  );
}
