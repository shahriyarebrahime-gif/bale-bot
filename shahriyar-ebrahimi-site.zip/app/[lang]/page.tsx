import Link from 'next/link';
import type { CSSProperties } from 'react';
import { notFound } from 'next/navigation';
import Counter from '@/components/Counter';
import Hero from '@/components/Hero';
import PhoneReveal from '@/components/PhoneReveal';
import Reveal from '@/components/Reveal';
import { dict } from '@/lib/content';
import { isLang, langInfo, languages } from '@/lib/i18n';
import { certificates, email, paperSlug, paperUrl, siteUrl } from '@/lib/site';

export const dynamicParams = false;

export function generateStaticParams() {
  return languages.map((lang) => ({ lang }));
}

export default async function HomePage({ params }: { params: Promise<{ lang: string }> }) {
  const { lang } = await params;
  if (!isLang(lang)) notFound();
  const d = dict[lang];
  const r = d.research;
  const locale = langInfo[lang].locale;

  const person = {
    '@context': 'https://schema.org',
    '@type': 'Person',
    name: 'Shahriyar Ebrahimi',
    url: `${siteUrl}/${lang}/`,
    jobTitle: 'Student',
    description: dict.en.meta.description,
    alumniOf: { '@type': 'School', name: 'Ejei 3 Gifted School' },
    address: { '@type': 'PostalAddress', addressLocality: 'Isfahan', addressCountry: 'IR' },
    knowsLanguage: ['fa', 'en', 'de'],
    email: `mailto:${email}`,
  };

  return (
    <main id="main">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(person) }} />
      <Hero d={d} />

      <div className="wrap">
        <div className="hl fade" style={{ '--d': '1s' } as CSSProperties} role="list">
          {d.highlights.map((h) => (
            <div role="listitem" key={h.label}>
              <b>
                <Counter to={h.value} decimals={h.decimals} suffix={h.suffix} locale={locale} />
              </b>
              <span>{h.label}</span>
            </div>
          ))}
        </div>
      </div>

      <section id="about">
        <div className="wrap two">
          <div>
            <Reveal>
              <h2>{d.about.title}</h2>
              <p className="lead">{d.about.paragraphs[0]}</p>
              <p className="gap">{d.about.paragraphs[1]}</p>
              <p className="gap">{d.about.paragraphs[2]}</p>
            </Reveal>
            <Reveal delay={120}>
              <div className="school">
                <h3>{d.about.schoolTitle}</h3>
                <p className="muted">{d.about.schoolText}</p>
              </div>
            </Reveal>
          </div>
          <div>
            <Reveal delay={100}>
              <h2>{d.profile.title}</h2>
              <dl className="profile">
                {d.profile.rows.map((row) => (
                  <div className="row" key={row.label}>
                    <dt>{row.label}</dt>
                    <dd>{row.value}</dd>
                  </div>
                ))}
              </dl>
              <div className="perf">
                <b>{d.profile.performance.value}</b>
                <span>{d.profile.performance.label}</span>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <section id="research" className="alt">
        <div className="wrap">
          <Reveal>
            <h2>{r.title}</h2>
          </Reveal>
          <Reveal delay={100}>
            <article className="paper">
              <h3 lang={r.paperTitleLang} dir={langInfo[r.paperTitleLang].dir}>
                {r.paperTitle}
              </h3>
              <p className="alt-title muted" lang={r.altTitleLang} dir={langInfo[r.altTitleLang].dir}>
                {r.altTitle}
              </p>
              <p>{r.topic}</p>
              <div className="facts">
                {r.facts.map((f) => (
                  <div key={f.label}>
                    <b>{f.label}</b>
                    {f.value}
                  </div>
                ))}
              </div>
              <div className="actions">
                <a className="btn solid" href={paperUrl} target="_blank" rel="noopener">
                  {r.read}
                </a>
                <Link className="btn line" href={`/${lang}/research/${paperSlug}/`}>
                  {r.publicationPage}
                </Link>
              </div>
            </article>
          </Reveal>
        </div>
      </section>

      <section id="achievements">
        <div className="wrap">
          <Reveal>
            <h2>{d.achievements.title}</h2>
          </Reveal>
          <div className="grid">
            {d.achievements.items.map((item, i) => (
              <Reveal key={item.id} delay={i * 70}>
                <article className="card">
                  <h3>{item.name}</h3>
                  <small>{d.achievements.year}</small>
                  <span className="chip">{d.achievements.status}</span>
                  {certificates[item.id] && (
                    <a href={certificates[item.id]} target="_blank" rel="noopener">
                      {d.ui.viewCertificate}
                    </a>
                  )}
                </article>
              </Reveal>
            ))}
          </div>
          <Reveal delay={200}>
            <p className="note">{d.achievements.note}</p>
          </Reveal>
        </div>
      </section>

      <section className="alt" id="interests">
        <div className="wrap two">
          <Reveal>
            <h2>{d.interests.title}</h2>
            <ul className="tags">
              {d.interests.items.map((t) => (
                <li key={t}>{t}</li>
              ))}
            </ul>
          </Reveal>
          <Reveal delay={100}>
            <h2>{d.languages.title}</h2>
            <div className="lang-list">
              {d.languages.items.map((l) => (
                <div key={l.name}>
                  <span>{l.name}</span>
                  <b>{l.level}</b>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <section id="journey">
        <div className="wrap">
          <Reveal>
            <h2>{d.journey.title}</h2>
          </Reveal>
          <ol className="tl">
            {d.journey.items.map((it, i) => (
              <li key={it.title} className={it.future ? 'future' : undefined}>
                <Reveal delay={i * 90}>
                  <h3>{it.title}</h3>
                  {it.text && <p className="muted">{it.text}</p>}
                </Reveal>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="alt contact" id="contact">
        <div className="wrap">
          <Reveal>
            <h2>{d.contact.title}</h2>
            <p className="muted">{d.contact.text}</p>
            <div className="actions">
              <a className="btn solid" href={`mailto:${email}`}>
                {d.contact.email}
              </a>
              <PhoneReveal label={d.ui.showPhone} />
            </div>
            <p className="note" dir="ltr" style={{ textAlign: lang === 'fa' ? 'right' : 'left' }}>
              {email}
            </p>
          </Reveal>
        </div>
      </section>
    </main>
  );
}
