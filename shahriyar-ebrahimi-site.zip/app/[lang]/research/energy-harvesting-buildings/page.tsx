import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import Reveal from '@/components/Reveal';
import { dict } from '@/lib/content';
import { isLang, langInfo, languages } from '@/lib/i18n';
import { paperSlug, paperUrl, siteUrl } from '@/lib/site';

export const dynamicParams = false;

export function generateStaticParams() {
  return languages.map((lang) => ({ lang }));
}

export async function generateMetadata({ params }: { params: Promise<{ lang: string }> }): Promise<Metadata> {
  const { lang } = await params;
  if (!isLang(lang)) return {};
  const r = dict[lang].research;
  const url = (l: string) => `${siteUrl}/${l}/research/${paperSlug}/`;
  const title = `${r.paperTitle} | Shahriyar Ebrahimi`;
  return {
    title,
    description: r.topic,
    alternates: {
      canonical: url(lang),
      languages: { ...Object.fromEntries(languages.map((l) => [l, url(l)])), 'x-default': url('en') },
    },
    openGraph: { type: 'article', title, description: r.topic, url: url(lang), locale: langInfo[lang].ogLocale },
  };
}

export default async function ResearchPage({ params }: { params: Promise<{ lang: string }> }) {
  const { lang } = await params;
  if (!isLang(lang)) notFound();
  const d = dict[lang];
  const r = d.research;

  const article = {
    '@context': 'https://schema.org',
    '@type': 'ScholarlyArticle',
    headline: dict.en.research.paperTitle,
    alternativeHeadline: dict.fa.research.paperTitle,
    author: { '@type': 'Person', name: 'Shahriyar Ebrahimi' },
    datePublished: '2026',
    url: paperUrl,
    isPartOf: { '@type': 'WebSite', name: 'BrainyScholar' },
  };

  return (
    <main id="main" className="page">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(article) }} />
      <div className="wrap narrow">
        <Link className="back" href={`/${lang}/#research`}>
          {d.ui.backToResearch}
        </Link>
        <Reveal>
          <h1 className="paper-h1" lang={r.paperTitleLang} dir={langInfo[r.paperTitleLang].dir}>
            {r.paperTitle}
          </h1>
          <p className="alt-title muted" lang={r.altTitleLang} dir={langInfo[r.altTitleLang].dir}>
            {r.altTitle}
          </p>
        </Reveal>

        <Reveal delay={100}>
          <div className="facts">
            {r.facts.map((f) => (
              <div key={f.label}>
                <b>{f.label}</b>
                {f.value}
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal delay={150}>
          <h2 className="h2-sm">{r.topicLabel}</h2>
          <p className="lead">{r.topic}</p>
        </Reveal>

        {r.sections?.map((s) => (
          <Reveal key={s.heading}>
            <h2 className="h2-sm">{s.heading}</h2>
            <p>{s.text}</p>
          </Reveal>
        ))}

        <Reveal delay={200}>
          <div className="actions">
            <a className="btn solid" href={paperUrl} target="_blank" rel="noopener">
              {r.read}
            </a>
          </div>
        </Reveal>
      </div>
    </main>
  );
}
