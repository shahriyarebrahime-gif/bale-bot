import type { MetadataRoute } from 'next';
import { languages } from '@/lib/i18n';
import { paperSlug, siteUrl } from '@/lib/site';

export const dynamic = 'force-static';

export default function sitemap(): MetadataRoute.Sitemap {
  const paths = ['', `research/${paperSlug}/`];
  return languages.flatMap((l) =>
    paths.map((p) => ({
      url: `${siteUrl}/${l}/${p}`,
      lastModified: new Date(),
      alternates: {
        languages: Object.fromEntries(languages.map((x) => [x, `${siteUrl}/${x}/${p}`])),
      },
    })),
  );
}
