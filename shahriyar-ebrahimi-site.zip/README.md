# Shahriyar Ebrahimi — Academic Website

Next.js (App Router) + TypeScript, static export. Languages: EN / FA / DE.

## Run locally
    npm install
    npm run dev        # http://localhost:3000
    npm run build      # static site in /out

## Where to edit
- Texts (all 3 languages): `lib/content.ts`
- Email, paper link, CV switch, certificates: `lib/site.ts`
- Look and animations: `app/globals.css`

## Add your CV
1. Put the PDF at `public/cv.pdf`
2. In `lib/site.ts` set `hasCv = true`

## Add a certificate
Put the file in `public/certificates/` and add it in `lib/site.ts`.

## Add research details (abstract, method, findings...)
In `lib/content.ts`, add `sections: [{ heading, text }]` to `research` in each language.
They appear on the research page automatically.

## Deploy (GitHub Pages)
Repo Settings → Pages → Source: GitHub Actions. Push to `main`.
For best SEO, name the repository `USERNAME.github.io` (site at the domain root) or connect your own domain.
