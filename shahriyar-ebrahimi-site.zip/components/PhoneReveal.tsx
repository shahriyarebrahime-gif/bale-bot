'use client';

import { useState } from 'react';

// Split on purpose so the number is not sitting in the page as one plain string.
const parts = ['+98', '913', '211', '1125'];

export default function PhoneReveal({ label }: { label: string }) {
  const [shown, setShown] = useState(false);

  if (shown) {
    return (
      <a className="phone" dir="ltr" href={`tel:${parts.join('')}`}>
        {parts.join(' ')}
      </a>
    );
  }
  return (
    <button type="button" className="btn line" onClick={() => setShown(true)}>
      {label}
    </button>
  );
}
