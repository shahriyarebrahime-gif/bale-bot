import type { CSSProperties } from 'react';
import type { Dict } from '@/lib/content';

const waves = [
  { d: 'M0 130 C 60 30 120 30 180 130 S 300 230 360 130 S 480 30 540 130 S 660 230 720 130', o: 0.55, delay: 0.3 },
  { d: 'M0 130 C 45 70 90 70 135 130 S 225 190 270 130 S 360 70 405 130 S 495 190 540 130 S 630 70 675 130 S 765 190 810 130', o: 0.32, delay: 0.6 },
  { d: 'M0 130 C 90 -10 150 -10 240 130 S 390 270 480 130 S 630 -10 720 130', o: 0.2, delay: 0.9 },
];

export default function Hero({ d }: { d: Dict }) {
  const words = d.name.split(' ');
  return (
    <section id="home" className="hero">
      <svg className="wave" viewBox="0 0 720 260" fill="none" aria-hidden="true" focusable="false">
        <line x1="0" y1="130" x2="720" y2="130" stroke="rgba(157,182,224,.25)" strokeDasharray="2 7" />
        {waves.map((w) => (
          <path
            key={w.d}
            d={w.d}
            pathLength={1}
            stroke={`rgba(157,182,224,${w.o})`}
            strokeWidth="1.5"
            style={{ animationDelay: `${w.delay}s` }}
          />
        ))}
      </svg>
      <div className="wrap hero-in">
        <p className="h-role fade" style={{ '--d': '.05s' } as CSSProperties}>
          {d.hero.role}
        </p>
        <h1 className="h-name">
          {words.map((w, i) => (
            <span className="w" key={w}>
              <span style={{ '--i': i } as CSSProperties}>{w}</span>
            </span>
          ))}
        </h1>
        <p className="h-line fade" style={{ '--d': '.55s' } as CSSProperties}>
          {d.hero.line}
        </p>
        <p className="h-tag fade" style={{ '--d': '.7s' } as CSSProperties}>
          {d.hero.tag}
        </p>
        <div className="actions fade" style={{ '--d': '.85s' } as CSSProperties}>
          <a className="btn primary" href="#research">
            {d.hero.ctaResearch}
          </a>
          <a className="btn ghost" href="#achievements">
            {d.hero.ctaAchievements}
          </a>
        </div>
      </div>
    </section>
  );
}
