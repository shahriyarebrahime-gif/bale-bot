'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Fragment, useEffect, useRef, useState } from 'react';
import type { Dict } from '@/lib/content';
import { langInfo, languages, type Lang } from '@/lib/i18n';
import { basePath } from '@/lib/site';

const sections = ['home', 'about', 'research', 'achievements', 'contact'] as const;

function switchPath(pathname: string, l: Lang) {
  const rest = pathname.replace(/^\/(en|fa|de)(?=\/|$)/, '');
  return `/${l}${rest || '/'}`;
}

export default function Header({
  lang,
  name,
  nav,
  ui,
  hasCv,
}: {
  lang: Lang;
  name: string;
  nav: Dict['nav'];
  ui: Dict['ui'];
  hasCv: boolean;
}) {
  const pathname = usePathname() ?? '';
  const isHome = pathname === `/${lang}` || pathname === `/${lang}/`;
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('home');
  const barRef = useRef<HTMLDivElement>(null);

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    let raf = 0;
    const update = () => {
      raf = 0;
      const y = window.scrollY;
      setScrolled(y > 8);
      const h = document.documentElement.scrollHeight - window.innerHeight;
      if (barRef.current) barRef.current.style.transform = `scaleX(${h > 0 ? Math.min(1, y / h) : 0})`;
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [pathname]);

  useEffect(() => {
    if (!isHome) {
      setActive('');
      return;
    }
    const els = sections.map((id) => document.getElementById(id)).filter(Boolean) as HTMLElement[];
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: '-45% 0px -50% 0px' },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [isHome]);

  const links = sections.map((id) => (
    <Link
      key={id}
      href={`/${lang}/#${id}`}
      aria-current={active === id ? 'true' : undefined}
      onClick={() => setOpen(false)}
    >
      {nav[id]}
    </Link>
  ));

  const remember = (l: Lang) => {
    try {
      localStorage.setItem('lang', l);
    } catch {}
  };

  return (
    <header className={`hdr${scrolled ? ' scrolled' : ''}`}>
      <div className="progress" ref={barRef} aria-hidden="true" />
      <div className="wrap bar">
        <Link className="brand" href={`/${lang}/`}>
          {name}
        </Link>
        <nav className="nav-d" aria-label="Main">
          {links}
        </nav>
        <div className="tools">
          <div className="lang" role="group" aria-label={ui.language}>
            {languages.map((l, i) => (
              <Fragment key={l}>
                {i > 0 && <span aria-hidden="true">|</span>}
                <Link
                  href={switchPath(pathname, l)}
                  hrefLang={l}
                  lang={l}
                  aria-current={l === lang ? 'true' : undefined}
                  onClick={() => remember(l)}
                >
                  {langInfo[l].label}
                </Link>
              </Fragment>
            ))}
          </div>
          {hasCv && (
            <a className="cv" href={`${basePath}/cv.pdf`} download>
              {nav.cv}
            </a>
          )}
          <button
            type="button"
            className="menu-btn"
            aria-expanded={open}
            aria-controls="mobile-nav"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? ui.close : ui.menu}
          </button>
        </div>
      </div>
      <nav id="mobile-nav" className={`nav-m${open ? ' open' : ''}`} aria-label="Mobile">
        <div className="wrap">
          {links}
          {hasCv && (
            <a href={`${basePath}/cv.pdf`} download>
              {nav.cv}
            </a>
          )}
        </div>
      </nav>
    </header>
  );
}
